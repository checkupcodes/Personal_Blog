-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 07 Tem 2022, 14:08:40
-- Sunucu sürümü: 10.4.21-MariaDB
-- PHP Sürümü: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `website`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `username`, `profile_image`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'user', 'user@gmail.com', NULL, '$2y$10$MLgO/Vx12yaPQbcV9ub6Gu4N6RACnOBJH2WUuqls6WYiDwYvMcRpK', NULL, NULL, 'd83K5LfdpcFCy8apwyHMPRcRGLSgLkf7HJFyao7v1gUE9B8epk3tmYVYVuAG', '2022-07-05 05:39:20', '2022-07-05 06:14:32'),
(4, 'cekap', 'cekapykp@gmail.com', '2022-07-05 06:29:33', '$2y$10$4zCD95rk0swNX/u.Y/HWz.G4l8yS1mltnOh0z9DP13vCY1EbMB6CO', NULL, NULL, NULL, '2022-07-05 06:27:22', '2022-07-05 06:29:33'),
(5, 'Yusuf', 'yusufdur@gmail.com', '2022-07-05 08:18:19', '$2y$10$A.38O90YPsCQQp1dpTgReuKMI2rdNgd2gx0lKGz2jKt5ukWiC9R4u', NULL, NULL, NULL, '2022-07-05 08:17:57', '2022-07-05 08:18:19'),
(6, 'Belali', 'belali@gmail.com', '2022-07-05 08:20:29', '$2y$10$SsV3cD1.kQ6fuLu7MxEhP.WeE/9quzE.qCoMM7NUTvDqamIcCpk7u', 'belali', '202207061819foto.jpeg', NULL, '2022-07-05 08:20:19', '2022-07-07 07:58:48'),
(7, 'Mustafa Sarı', 'mustafasari@gmail.com', '2022-07-06 06:49:06', '$2y$10$doAm6ZT7WEKyAGztL.2Que9gY.xfYicjAMMK92EzV85p7cLmg/oBq', 'mustafa', '202207062103images.png', NULL, '2022-07-06 06:48:49', '2022-07-06 18:03:50'),
(8, 'xcekap', 'xcekapykp@gmail.com', '2022-07-06 09:58:25', '$2y$10$zvYGJEBPkpFpJMp860/XmurTaRtoldsPlA6naAvNhlP7rI13pjYZG', 'gurdecekap', NULL, NULL, '2022-07-06 09:58:16', '2022-07-06 09:58:25'),
(9, 'Selma Sari', 'selmasari@gmail.com', '2022-07-06 11:32:13', '$2y$10$6Jt64nBZXsYVmqHf/n1q5eIe1N5tWGZzk4h.JYuCw/.EtWDAPTZYy', 'marsmelow', NULL, NULL, '2022-07-06 11:30:37', '2022-07-06 11:32:13'),
(10, 'Elif Sarı', 'xxcokomel@gmail.com', '2022-07-06 13:05:10', '$2y$10$8QlaxO1j8D1QNTJ5Ps7Mbe/qSjTdvzn6Ya8YL5Hk4xrotzymeyDZ6', 'cokomel', NULL, NULL, '2022-07-06 13:04:48', '2022-07-06 13:05:10');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
